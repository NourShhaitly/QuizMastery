package easy.tuto.myquizapplication;

public class QuestionAnswer2 {
    public static String question[] ={
            "What is osmosis?",
            "What helps keeping a water-balance in the cells.?",
            "The gradual, even spreading out of molecules is known as",
            "When the plasma membrane moves molecules against diffusion pressure, energy is needed. This is called."
    };

    public static String choices[][] = {
            {"Concentration of water","Diffusion of water","Gravity of water","None of the above"},
            {"Contractile vacuoles","Hypotonic","Turgor pressure","Plasmolysis"},
            {"Particles","Molecules","Diffusion","Plasma"},
            {"Lower transport","Active transport","Hypothesis","Endocytosis"}
    };

    public static String correctAnswers[] = {
            "Diffusion of water",
            "Contractile vacuoles",
            "Diffusion",
            "Active transport"
    };

}

package easy.tuto.myquizapplication;

public class QuestionAnswer3 {

    public static String question[] = {
            "What is the name of this chemical? NH4+",
            "What is the name of this chemical? CrO42",
            "What is CO32- called?",
            "What is the difference between sulfate and sulfite?"

    };
    public static String choices[][] = {
            {"Ammonium","Nitrite","Hydroxide","Acetate"},
            {"Phosphate","Carbonate","Chromate","Sulfate"},
            {"Chromate","Carbonate","Nitrite","Phosphate"},
            {"There is no difference,they are the same thing","Sulfate has one more oxygen than sulfite.","Sulfate has a positive charge while sulfite has a negative charge.","Sulfite has one less sulfur than sulfate."}
    };
    public static String correctAnswers[] = {
            "Ammonium",
            "Chromate",
            "Carbonate",
            "Sulfate has one more oxygen than sulfite."
    };
}


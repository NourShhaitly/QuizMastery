package easy.tuto.myquizapplication;

public class QuestionAnswer1 {

    public static String question[] ={
            "Which company owns the android?",
            "Which one is not the programming language?",
            "Who is the owner of Facebook?",
            "Which company owns the Apple?"
    };

    public static String choices[][] = {
            {"Google","Apple","Nokia","Samsung"},
            {"Java","Kotlin","Notepad","Python"},
            {"Elon Musk","Justin Beiber","Mark Zuckerberg","Rihaj Bou Hamdan"},
            {"Google","Apple","Nokia","Samsung"}
    };

    public static String correctAnswers[] = {
            "Google",
            "Notepad",
            "Mark Zuckerberg",
            "Apple"
    };

}

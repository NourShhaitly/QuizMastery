package easy.tuto.myquizapplication;

public class QuestionAnswer4 {
    public static String question[] = {
            "What type of lens is a Magnifying Glass?",
            "What is the bending of light rays due to a change in speed as the rays pass through a substance, called?",
            "What is the medical word for nearsightedness?",
            "A  uses large mirrors to bring distant objects into closer view."

    };
    public static String choices[][]={
            {"Convex","Concave","Parabolic","Plane"},
            {"Diffusion","Reflection","Refraction","Diffraction"},
            {"Glaucoma","Plybaria","Hyperopia","Myopia"},
            {"Microscope","Telescope","Oscilloscope","Kalidescope"}
    };
    public static String correctAnswers[]={
            "Convex",
            "Refraction",
            "Myopia",
            "Telescope"


    };
}


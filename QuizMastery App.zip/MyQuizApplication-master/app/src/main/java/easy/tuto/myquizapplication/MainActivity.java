package easy.tuto.myquizapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activityy);
        CardView card1=findViewById(R.id.cardview1);
        CardView card2=findViewById(R.id.cardview2);
        CardView card3 = findViewById(R.id.cardView3);
        CardView card4 = findViewById(R.id.cardView4);
        // Set a click listener on that View
      card1.setOnClickListener(view -> {
          Intent intent=new Intent(MainActivity.this, MainActivity1.class);

          startActivity(intent);



      });
      card2.setOnClickListener(view -> {

          Intent intent=new Intent(MainActivity.this, MainActivity2.class);

          startActivity(intent);

      });
        card3.setOnClickListener(view -> {

            Intent intent = new Intent(MainActivity.this,MainActivity3.class);
            startActivity(intent);
        });
        card4.setOnClickListener(view -> {

            Intent intent = new Intent(MainActivity.this,MainActivity4.class);
            startActivity(intent);
        });
    }
}